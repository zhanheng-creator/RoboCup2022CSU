package maps;

/**
   Top-level interface for all types of map.
*/
public interface Map {
}